create trigger member_insert
  after INSERT
  on uc_member
  for each row
  BEGIN
		INSERT INTO `uc_member_log`(`member_id`, `account`, `password`, `uid`, `agent`, `level`, `category`, `real_name`, `mobile`, `qq`, `wx`, `email`, `note`, `birthday`, `withdrawal_code`, `amount`, `ag_amount`, `agq_amount`, `lebo_amount`, `ds_amount`, `ab_amount`, `mg_amount`, `bbin_amount`, `sss_amount`, `deposit_count`, `deposit_amount`, `withdrawal_count`, `withdrawal_amount`, `bank_name`, `bank_address`, `bank_number`, `register_from`, `register_ip`, `register_time`, `login_ip`, `login_time`, `action`, `active_time`, `online`, `password_time`, `status`, `browser`, `casino_online`) values (new.`member_id`, new.`account`, new.`password`, new.`uid`, new.`agent`, new.`level`, new.`category`, new.`real_name`, new.`mobile`, new.`qq`, new.`wx`, new.`email`, new.`note`, new.`birthday`, new.`withdrawal_code`, new.`amount`, new.`ag_amount`, new.`agq_amount`, new.`lebo_amount`, new.`ds_amount`, new.`ab_amount`, new.`mg_amount`, new.`bbin_amount`, new.`sss_amount`, new.`deposit_count`, new.`deposit_amount`, new.`withdrawal_count`, new.`withdrawal_amount`, new.`bank_name`, new.`bank_address`, new.`bank_number`, new.`register_from`, new.`register_ip`, new.`register_time`, new.`login_ip`, new.`login_time`, new.`action`, new.`active_time`, new.`online`, new.`password_time`, new.`status`, new.`browser`, new.`casino_online`);
    END;

